function themeSwitcher() {
    document.querySelector('.Background-Light').classList.toggle('Background-Dark');
    document.querySelector('.Background-Form-Light').classList.toggle('Background-Form-Dark');
    document.querySelector('.text-grey-darkest').classList.toggle('text-white');
}